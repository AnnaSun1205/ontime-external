# OnTime Source Code Export

This file contains all source code needed to migrate to a new Lovable project.

**Instructions:**
1. Create a new Lovable project (with Cloud DISABLED)
2. Connect it to your own Supabase project
3. Copy each file below into the new project

---

## Core Files

### src/App.tsx
```tsx
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Onboarding from "./pages/Onboarding";
import AuthCallback from "./pages/AuthCallback";
import AppLayout from "./pages/app/AppLayout";
import CalendarTab from "./pages/app/CalendarTab";
import InboxTab from "./pages/app/InboxTab";
import CompaniesTab from "./pages/app/CompaniesTab";
import SettingsTab from "./pages/app/SettingsTab";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route path="/app" element={<AppLayout />}>
            <Route index element={<CalendarTab />} />
            <Route path="inbox" element={<InboxTab />} />
            <Route path="companies" element={<CompaniesTab />} />
            <Route path="settings" element={<SettingsTab />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
```

### src/App.css
```css
#root {
  max-width: 1280px;
  margin: 0 auto;
  padding: 2rem;
  text-align: center;
}

.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.react:hover {
  filter: drop-shadow(0 0 2em #61dafbaa);
}

@keyframes logo-spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

@media (prefers-reduced-motion: no-preference) {
  a:nth-of-type(2) .logo {
    animation: logo-spin infinite 20s linear;
  }
}

.card {
  padding: 2em;
}

.read-the-docs {
  color: #888;
}
```

### src/index.css
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@import url('https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&display=swap');

@layer base {
  :root {
    /* Primary page background: #EBF4FF */
    --background: 214 100% 96%;
    /* Primary text: #0F172A */
    --foreground: 222 47% 11%;

    /* Card background: #FFFFFF */
    --card: 0 0% 100%;
    --card-foreground: 222 47% 11%;

    --popover: 0 0% 100%;
    --popover-foreground: 222 47% 11%;

    --primary: 222 47% 11%;
    --primary-foreground: 0 0% 100%;

    /* Secondary soft background: #DBEAFE */
    --secondary: 214 95% 93%;
    --secondary-foreground: 222 47% 11%;

    /* Muted text: #64748B */
    --muted: 214 95% 93%;
    --muted-foreground: 215 16% 47%;

    --accent: 38 92% 50%;
    --accent-foreground: 0 0% 100%;

    --destructive: 0 84% 50%;
    --destructive-foreground: 0 0% 100%;

    /* Borders: rgba(0, 0, 0, 0.06) approximated */
    --border: 0 0% 94%;
    --input: 0 0% 94%;
    --ring: 222 47% 11%;

    --radius: 0.75rem;

    /* OnTime specific tokens */
    --surface-soft: 214 95% 93%;
    
    /* Calendar & Signal colors */
    --status-live: 0 84% 60%;
    --status-live-bg: 0 84% 95%;
    --status-prepare: 38 92% 44%;
    --status-prepare-bg: 38 92% 95%;
    --status-opens-soon: 142 76% 36%;
    --status-opens-soon-bg: 142 76% 95%;
    --status-expected: 217 91% 60%;
    --status-expected-bg: 217 91% 95%;

    /* Secondary text: #475569 */
    --text-secondary: 215 19% 35%;

    --sidebar-background: 0 0% 100%;
    --sidebar-foreground: 215 19% 35%;
    --sidebar-primary: 222 47% 11%;
    --sidebar-primary-foreground: 0 0% 100%;
    --sidebar-accent: 214 95% 93%;
    --sidebar-accent-foreground: 222 47% 11%;
    --sidebar-border: 0 0% 94%;
    --sidebar-ring: 222 47% 11%;
  }

  .dark {
    --background: 222 47% 8%;
    --foreground: 0 0% 95%;

    --card: 222 47% 11%;
    --card-foreground: 0 0% 95%;

    --popover: 222 47% 11%;
    --popover-foreground: 0 0% 95%;

    --primary: 0 0% 95%;
    --primary-foreground: 222 47% 11%;

    --secondary: 222 30% 18%;
    --secondary-foreground: 0 0% 95%;

    --muted: 222 30% 18%;
    --muted-foreground: 215 16% 60%;

    --accent: 38 92% 50%;
    --accent-foreground: 0 0% 100%;

    --destructive: 0 62% 30%;
    --destructive-foreground: 0 0% 95%;

    --border: 222 20% 20%;
    --input: 222 20% 20%;
    --ring: 0 0% 80%;

    --surface-soft: 222 30% 15%;
    
    --status-live: 0 84% 60%;
    --status-live-bg: 0 50% 20%;
    --status-prepare: 38 92% 50%;
    --status-prepare-bg: 38 50% 20%;
    --status-opens-soon: 142 76% 45%;
    --status-opens-soon-bg: 142 50% 15%;
    --status-expected: 217 91% 60%;
    --status-expected-bg: 217 50% 20%;

    --text-secondary: 215 16% 60%;

    --sidebar-background: 222 47% 11%;
    --sidebar-foreground: 215 16% 70%;
    --sidebar-primary: 0 0% 95%;
    --sidebar-primary-foreground: 222 47% 11%;
    --sidebar-accent: 222 30% 18%;
    --sidebar-accent-foreground: 0 0% 95%;
    --sidebar-border: 222 20% 20%;
    --sidebar-ring: 0 0% 80%;
  }
}

@layer base {
  * {
    @apply border-border;
  }

  body {
    @apply bg-background text-foreground font-sans antialiased;
  }

  html {
    scroll-behavior: smooth;
  }
}

@layer components {
  .brand-text {
    @apply italic font-semibold;
  }
}
```

### src/main.tsx
```tsx
import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

createRoot(document.getElementById("root")!).render(<App />);
```

### tailwind.config.ts
```ts
import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./pages/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./app/**/*.{ts,tsx}", "./src/**/*.{ts,tsx}"],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar-background))",
          foreground: "hsl(var(--sidebar-foreground))",
          primary: "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border: "hsl(var(--sidebar-border))",
          ring: "hsl(var(--sidebar-ring))",
        },
        surface: {
          soft: "hsl(var(--surface-soft))",
        },
        status: {
          live: "hsl(var(--status-live))",
          "live-bg": "hsl(var(--status-live-bg))",
          prepare: "hsl(var(--status-prepare))",
          "prepare-bg": "hsl(var(--status-prepare-bg))",
          "opens-soon": "hsl(var(--status-opens-soon))",
          "opens-soon-bg": "hsl(var(--status-opens-soon-bg))",
          expected: "hsl(var(--status-expected))",
          "expected-bg": "hsl(var(--status-expected-bg))",
        },
        "text-secondary": "hsl(var(--text-secondary))",
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "fade-in": {
          "0%": { opacity: "0", transform: "translateY(10px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "fade-in-up": {
          "0%": { opacity: "0", transform: "translateY(30px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pulse-subtle": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.6" },
        },
        "slow-pulse": {
          "0%, 100%": { opacity: "1", transform: "scale(1)" },
          "50%": { opacity: "0.85", transform: "scale(0.98)" },
        },
        "scroll-left": {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        "clock-tick": {
          "0%, 100%": { transform: "rotate(0deg)" },
          "25%": { transform: "rotate(2deg)" },
          "75%": { transform: "rotate(-2deg)" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "fade-in": "fade-in 0.6s ease-out forwards",
        "fade-in-up": "fade-in-up 0.8s ease-out forwards",
        "pulse-subtle": "pulse-subtle 3s ease-in-out infinite",
        "slow-pulse": "slow-pulse 4s ease-in-out infinite",
        "scroll-left": "scroll-left 30s linear infinite",
        "clock-tick": "clock-tick 6s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;
```

### index.html
```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>OnTime - Internship Calendar</title>
    <meta name="description" content="Never miss an internship deadline again. Get personalized alerts when applications open." />
    <meta name="author" content="OnTime" />

    <meta property="og:title" content="OnTime - Internship Calendar" />
    <meta property="og:description" content="Never miss an internship deadline again." />
    <meta property="og:type" content="website" />

    <meta name="twitter:card" content="summary_large_image" />
  </head>

  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

---

## src/lib/

### src/lib/utils.ts
```ts
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

### src/lib/calendarUtils.ts
```ts
import { addMonths, startOfMonth, endOfMonth, eachDayOfInterval, format, isSameMonth, isWithinInterval } from "date-fns";

export type EventType = "prep" | "live" | "window";
export type EventState = "opens-soon" | "prepare" | "live";

export interface CalendarEvent {
  id: string;
  company: string;
  role: string;
  type: EventType;
  state: EventState;
  date?: Date;
  startDate?: Date;
  endDate?: Date;
  urgency?: string;
  link?: string;
}

export interface SeasonDateRange {
  startMonth: number;
  endMonth: number;
  startYear: number;
  endYear: number;
}

export function getSeasonDateRange(season: string, baseYear: number): SeasonDateRange {
  switch (season.toLowerCase()) {
    case "summer":
      return { startMonth: 8, endMonth: 3, startYear: baseYear, endYear: baseYear + 1 };
    case "fall":
      return { startMonth: 4, endMonth: 8, startYear: baseYear, endYear: baseYear };
    case "winter":
      return { startMonth: 7, endMonth: 0, startYear: baseYear, endYear: baseYear + 1 };
    default:
      return { startMonth: 0, endMonth: 11, startYear: baseYear, endYear: baseYear };
  }
}

export function combineSeasonRanges(seasons: string[], baseYear: number): { start: Date; end: Date } {
  if (seasons.length === 0) {
    const now = new Date();
    return { start: startOfMonth(now), end: endOfMonth(addMonths(now, 6)) };
  }

  const ranges = seasons.map(s => getSeasonDateRange(s, baseYear));
  
  let earliestStart = new Date(ranges[0].startYear, ranges[0].startMonth, 1);
  let latestEnd = new Date(ranges[0].endYear, ranges[0].endMonth, 1);
  
  ranges.forEach(range => {
    const start = new Date(range.startYear, range.startMonth, 1);
    const end = new Date(range.endYear, range.endMonth, 1);
    
    if (start < earliestStart) earliestStart = start;
    if (end > latestEnd) latestEnd = end;
  });
  
  return { start: startOfMonth(earliestStart), end: endOfMonth(latestEnd) };
}

export function generateCalendarEvents(
  companies: string[],
  roles: string[],
  dateRange: { start: Date; end: Date }
): CalendarEvent[] {
  const events: CalendarEvent[] = [];
  const totalDays = Math.ceil((dateRange.end.getTime() - dateRange.start.getTime()) / (1000 * 60 * 60 * 24));
  
  companies.forEach((company, companyIndex) => {
    const companyRoles = roles.slice(0, Math.min(2, roles.length));
    
    companyRoles.forEach((role, roleIndex) => {
      const seed = (companyIndex * 17 + roleIndex * 31) % 100;
      const offsetDays = Math.floor((seed / 100) * (totalDays - 30)) + 15;
      
      const goLiveDate = new Date(dateRange.start);
      goLiveDate.setDate(goLiveDate.getDate() + offsetDays);
      goLiveDate.setHours(0, 0, 0, 0);
      
      if (goLiveDate >= dateRange.start && goLiveDate <= dateRange.end) {
        events.push({
          id: `${company}-${role}-live`,
          company,
          role,
          type: "live",
          state: "live",
          date: goLiveDate,
          urgency: "Apply today",
          link: "#",
        });
      }
    });
  });
  
  return events.sort((a, b) => {
    const dateA = a.date || a.startDate || new Date();
    const dateB = b.date || b.startDate || new Date();
    return dateA.getTime() - dateB.getTime();
  });
}

export function isInPrepWeek(day: Date, liveEvents: CalendarEvent[]): CalendarEvent | null {
  const dayStr = formatDateKey(day);
  
  for (const event of liveEvents) {
    if (!event.date) continue;
    
    for (let offset = 1; offset <= 6; offset++) {
      const prepDay = new Date(event.date);
      prepDay.setDate(prepDay.getDate() - offset);
      prepDay.setHours(0, 0, 0, 0);
      
      if (formatDateKey(prepDay) === dayStr) {
        return event;
      }
    }
  }
  
  return null;
}

export function hasLiveEventsInMonth(month: Date, liveEvents: CalendarEvent[]): boolean {
  const monthYear = month.getFullYear();
  const monthIndex = month.getMonth();
  
  return liveEvents.some(event => {
    if (!event.date) return false;
    return event.date.getFullYear() === monthYear && event.date.getMonth() === monthIndex;
  });
}

export function formatDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getLiveEventsForDay(events: CalendarEvent[], day: Date): CalendarEvent[] {
  const dayStr = formatDateKey(day);
  return events.filter(e => e.type === "live" && e.date && formatDateKey(e.date) === dayStr);
}

function isSameDay(date1: Date, date2: Date): boolean {
  return (
    date1.getFullYear() === date2.getFullYear() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getDate() === date2.getDate()
  );
}

export function generateMonths(dateRange: { start: Date; end: Date }): Date[] {
  const months: Date[] = [];
  let current = startOfMonth(dateRange.start);
  
  while (current <= dateRange.end) {
    months.push(current);
    current = addMonths(current, 1);
  }
  
  return months;
}

export function getWeeksForMonth(month: Date): (Date | null)[][] {
  const start = startOfMonth(month);
  const end = endOfMonth(month);
  const days = eachDayOfInterval({ start, end });
  
  const weeks: (Date | null)[][] = [];
  let currentWeek: (Date | null)[] = [];
  
  const startDayOfWeek = start.getDay();
  const mondayOffset = startDayOfWeek === 0 ? 6 : startDayOfWeek - 1;
  for (let i = 0; i < mondayOffset; i++) {
    currentWeek.push(null);
  }
  
  days.forEach(day => {
    currentWeek.push(day);
    if (currentWeek.length === 7) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
  });
  
  if (currentWeek.length > 0) {
    while (currentWeek.length < 7) {
      currentWeek.push(null);
    }
    weeks.push(currentWeek);
  }
  
  return weeks;
}
```

---

## src/hooks/

### src/hooks/useScrollAnimation.tsx
```tsx
import { useEffect, useRef, useState } from "react";

export function useScrollAnimation(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold }
    );

    const current = ref.current;
    if (current) {
      observer.observe(current);
    }

    return () => {
      if (current) {
        observer.unobserve(current);
      }
    };
  }, [threshold]);

  return { ref, isVisible };
}
```

### src/hooks/use-mobile.tsx
```tsx
import * as React from "react";

const MOBILE_BREAKPOINT = 768;

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined);

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    };
    mql.addEventListener("change", onChange);
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    return () => mql.removeEventListener("change", onChange);
  }, []);

  return !!isMobile;
}
```

---

## Assets

Copy the following files manually:
- `src/assets/ontime-icon.png`
- `src/assets/ontime-logo.png`

---

## UI Components

Copy the entire `src/components/ui/` directory from the original project. Key files include:
- button.tsx (includes oauth variant)
- accordion.tsx
- alert-dialog.tsx
- card.tsx
- checkbox.tsx
- command.tsx
- dialog.tsx
- dropdown-menu.tsx
- form.tsx
- input.tsx
- label.tsx
- popover.tsx
- select.tsx
- separator.tsx
- switch.tsx
- table.tsx
- tabs.tsx
- toast.tsx
- toaster.tsx
- tooltip.tsx

---

## Additional Files to Copy

Due to file size, the following files should be copied directly from the project:

### Pages:
- src/pages/Login.tsx
- src/pages/Signup.tsx
- src/pages/Index.tsx
- src/pages/Onboarding.tsx
- src/pages/AuthCallback.tsx
- src/pages/NotFound.tsx
- src/pages/app/AppLayout.tsx
- src/pages/app/CalendarTab.tsx
- src/pages/app/InboxTab.tsx
- src/pages/app/CompaniesTab.tsx
- src/pages/app/SettingsTab.tsx

### Components:
- src/components/Header.tsx
- src/components/Footer.tsx
- src/components/Logo.tsx
- src/components/NavLink.tsx
- src/components/companies/AddCompanyModal.tsx
- src/components/companies/EditCompanyModal.tsx

### Landing Sections:
- src/components/landing/HeroSection.tsx
- src/components/landing/SellingPointsSection.tsx
- src/components/landing/HowItWorksSection.tsx
- src/components/landing/ProductPreviewSection.tsx
- src/components/landing/CompaniesSection.tsx
- src/components/landing/CompanyLogosSection.tsx
- src/components/landing/PricingSection.tsx
- src/components/landing/FAQSection.tsx
- src/components/landing/IntroAnimation.tsx

### Hooks:
- src/hooks/useUserPreferences.ts
- src/hooks/useCalendarData.ts
- src/hooks/useBoards.ts
- src/hooks/useEvents.ts
- src/hooks/useBoardCompanies.ts
- src/hooks/use-toast.ts

---

## After Migration

1. Run the SQL from `MIGRATION_PACKAGE.md` to create the database schema
2. Configure OAuth providers (Apple, Google, Microsoft) in Supabase Dashboard
3. Update Login.tsx and Signup.tsx to add Apple + Microsoft OAuth buttons (see MIGRATION_PACKAGE.md)
4. Test authentication flow
5. Verify all features work correctly

---

## Notes

- Do NOT copy `src/integrations/supabase/` - this will be auto-generated
- Do NOT copy `.env` - configure in new project
- Do NOT copy `supabase/` folder - use your own Supabase project
