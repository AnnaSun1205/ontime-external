-- Add has_onboarded column and auth provider info to user_preferences
ALTER TABLE public.user_preferences 
ADD COLUMN IF NOT EXISTS has_onboarded BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS auth_provider TEXT,
ADD COLUMN IF NOT EXISTS last_login TIMESTAMP WITH TIME ZONE DEFAULT now();

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_user_preferences_user_id ON public.user_preferences(user_id);