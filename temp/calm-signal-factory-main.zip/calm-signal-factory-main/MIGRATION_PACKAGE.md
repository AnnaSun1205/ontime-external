# OnTime Project Migration Package

This file contains all the source code and SQL schema needed to migrate to a new Lovable project with your own Supabase instance.

---

## STEP 1: Create New Lovable Project

1. Create a new Lovable project with **Cloud DISABLED**
2. Go to `Settings → Connectors → Supabase` and connect your Supabase project
3. Run the SQL schema below in your Supabase dashboard

---

## STEP 2: Database Schema (Run in Supabase SQL Editor)

```sql
-- ============================================
-- OnTime Database Schema with RLS Policies
-- ============================================

-- 1. PROFILES TABLE
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  email TEXT,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own profile" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);

-- 2. USER_PREFERENCES TABLE
CREATE TABLE public.user_preferences (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  selected_seasons TEXT[] DEFAULT '{}',
  selected_regions TEXT[] DEFAULT '{}',
  selected_roles TEXT[] DEFAULT '{}',
  selected_companies TEXT[] DEFAULT '{}',
  email TEXT,
  quiet_mode BOOLEAN DEFAULT true,
  has_onboarded BOOLEAN DEFAULT false,
  last_login TIMESTAMP WITH TIME ZONE DEFAULT now(),
  auth_provider TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.user_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own preferences" ON public.user_preferences FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own preferences" ON public.user_preferences FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own preferences" ON public.user_preferences FOR UPDATE USING (auth.uid() = user_id);

-- 3. USER_SETTINGS TABLE
CREATE TABLE public.user_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  timezone TEXT DEFAULT 'America/New_York',
  theme TEXT DEFAULT 'light',
  notifications_enabled BOOLEAN DEFAULT true,
  reminder_days_before INTEGER DEFAULT 7,
  week_start_day INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own settings" ON public.user_settings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own settings" ON public.user_settings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own settings" ON public.user_settings FOR UPDATE USING (auth.uid() = user_id);

-- 4. BOARDS TABLE
CREATE TABLE public.boards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  season TEXT NOT NULL,
  start_date DATE,
  end_date DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.boards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own boards" ON public.boards FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own boards" ON public.boards FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own boards" ON public.boards FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own boards" ON public.boards FOR DELETE USING (auth.uid() = user_id);

-- 5. BOARD_COMPANIES TABLE
CREATE TABLE public.board_companies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  board_id UUID NOT NULL REFERENCES public.boards(id) ON DELETE CASCADE,
  company_name TEXT NOT NULL,
  status TEXT DEFAULT 'interested',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.board_companies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own board_companies" ON public.board_companies FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own board_companies" ON public.board_companies FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own board_companies" ON public.board_companies FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own board_companies" ON public.board_companies FOR DELETE USING (auth.uid() = user_id);

-- 6. EVENTS TABLE
CREATE TABLE public.events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  board_id UUID NOT NULL REFERENCES public.boards(id) ON DELETE CASCADE,
  company_name TEXT NOT NULL,
  title TEXT NOT NULL,
  event_type TEXT NOT NULL,
  start_at TIMESTAMP WITH TIME ZONE NOT NULL,
  end_at TIMESTAMP WITH TIME ZONE,
  source TEXT NOT NULL DEFAULT 'generated',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own events" ON public.events FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create their own events" ON public.events FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own events" ON public.events FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own events" ON public.events FOR DELETE USING (auth.uid() = user_id);

-- 7. HELPER FUNCTION FOR UPDATED_AT
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 8. TRIGGERS
CREATE TRIGGER update_user_preferences_updated_at
  BEFORE UPDATE ON public.user_preferences
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_user_settings_updated_at
  BEFORE UPDATE ON public.user_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
```

---

## STEP 3: Configure OAuth Providers

In your Supabase Dashboard → Authentication → Providers:

### Apple Sign-In (Required for App Store)
1. Enable Apple provider
2. Create App ID in Apple Developer Console
3. Create Service ID for Sign in with Apple
4. Generate private key
5. Add credentials to Supabase

### Google OAuth
1. Enable Google provider
2. Create OAuth 2.0 credentials in Google Cloud Console
3. Add Supabase callback URL
4. Add Client ID and Secret to Supabase

### Microsoft OAuth (Optional)
1. Enable Azure provider
2. Register app in Azure AD
3. Add credentials to Supabase

---

## STEP 4: Files to Copy

Copy all files from these directories to your new project:

### Core Files
- `src/App.tsx`
- `src/App.css`
- `src/index.css`
- `src/main.tsx`
- `tailwind.config.ts`
- `index.html`

### Directories
- `src/components/` (all files)
- `src/pages/` (all files)
- `src/hooks/` (all files)
- `src/lib/` (all files)
- `src/assets/` (all files)

### DO NOT COPY
- `src/integrations/supabase/` (Lovable auto-generates this)
- `.env` (auto-generated)
- `supabase/` folder

---

## STEP 5: Update Auth for Apple/Google/Microsoft

After copying files, update `src/pages/Login.tsx` and `src/pages/Signup.tsx` to add Apple and Microsoft sign-in buttons:

```tsx
// Add these handlers in Login.tsx and Signup.tsx:

const handleAppleSignIn = async () => {
  setLoading("apple");
  try {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "apple",
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    if (error) {
      toast.error(error.message || "Failed to sign in with Apple");
      setLoading(null);
    }
  } catch (err) {
    toast.error("Failed to sign in with Apple. Please try again.");
    setLoading(null);
  }
};

const handleMicrosoftSignIn = async () => {
  setLoading("microsoft");
  try {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "azure",
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
        scopes: "email profile openid",
      },
    });
    if (error) {
      toast.error(error.message || "Failed to sign in with Microsoft");
      setLoading(null);
    }
  } catch (err) {
    toast.error("Failed to sign in with Microsoft. Please try again.");
    setLoading(null);
  }
};
```

Add buttons in the auth UI:

```tsx
{/* Apple Sign-In Button */}
<Button
  type="button"
  variant="oauth"
  className="w-full h-12"
  onClick={handleAppleSignIn}
  disabled={loading !== null}
>
  {loading === "apple" ? (
    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
  ) : (
    <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
      <path fill="currentColor" d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
    </svg>
  )}
  {loading === "apple" ? "Signing in..." : "Continue with Apple"}
</Button>

{/* Microsoft Sign-In Button */}
<Button
  type="button"
  variant="oauth"
  className="w-full h-12"
  onClick={handleMicrosoftSignIn}
  disabled={loading !== null}
>
  {loading === "microsoft" ? (
    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
  ) : (
    <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
      <path fill="#F25022" d="M0 0h11.377v11.372H0z"/>
      <path fill="#00A4EF" d="M0 12.623h11.377V24H0z"/>
      <path fill="#7FBA00" d="M12.623 0H24v11.372H12.623z"/>
      <path fill="#FFB900" d="M12.623 12.623H24V24H12.623z"/>
    </svg>
  )}
  {loading === "microsoft" ? "Signing in..." : "Continue with Microsoft"}
</Button>
```

---

## Notes

- **Assets**: The `src/assets/` folder contains logo images. Copy these manually or re-upload in your new project.
- **Dependencies**: The new project should auto-detect dependencies from the code. If not, check `package.json` from the original.
- **Types**: The Supabase types file (`src/integrations/supabase/types.ts`) will be auto-generated after connecting your Supabase project.

---

## Summary Checklist

- [ ] Create new Lovable project (Cloud OFF)
- [ ] Connect your Supabase project
- [ ] Run SQL schema in Supabase
- [ ] Configure Apple OAuth in Supabase
- [ ] Configure Google OAuth in Supabase
- [ ] (Optional) Configure Microsoft OAuth
- [ ] Copy all source files
- [ ] Update Login/Signup with Apple + Microsoft buttons
- [ ] Test authentication flow
- [ ] Enable auto-confirm email in Supabase Auth settings
